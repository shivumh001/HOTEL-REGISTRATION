"""
Gadag & Koppal District Candidate Info Chatbot (Ollama + Llama 3.2)
----------------------------------------------------------------------
Answers questions about the 2023 Karnataka Assembly election candidates
(winner + runner-up) for all constituencies in Gadag and Koppal districts,
using the data in candidates_2023_election.csv.

This is a RAG-style chatbot: it never guesses or recalls facts from the
model's own training. It retrieves matching rows from the CSV and gives
ONLY that data to Llama, which is instructed to answer strictly from it.

Prerequisites (run on your local machine):
    1. Install Ollama:            https://ollama.com/download
    2. Pull the model:            ollama pull llama3.2:latest
    3. Install python libraries:  pip install ollama pandas

Setup:
    1. Place candidates_2023_election.csv in the same folder as this script.
    2. Run: python gadag_koppal_candidate_chatbot.py
"""

import os
import re
import pandas as pd
import ollama

MODEL_NAME = "llama3.2:latest"
CSV_PATH = "candidates_2023_election.csv"

SYSTEM_PROMPT = """You are "ElectionInfoBot", an assistant answering questions about
the 2023 Karnataka Assembly election candidates in Gadag and Koppal districts.

Rules:
- Only use facts present in the CANDIDATE DATA given to you in the user message.
  Never guess, assume, or invent any name, vote count, margin, or party that
  isn't explicitly there.
- If a field says "NOT_SPECIFIED_IN_SOURCE", tell the user that specific detail
  wasn't available in the source data - do not make up a number.
- If the data needed to answer isn't in what you were given, say clearly:
  "I don't have that information in the dataset."
- Be neutral and factual. Do not offer opinions on any candidate or party,
  and do not speculate about future elections or electability.
- Keep answers concise; use bullet points when listing multiple fields.
"""


def load_data(path: str) -> pd.DataFrame:
    if not os.path.exists(path):
        raise FileNotFoundError(
            f"'{path}' not found. Make sure candidates_2023_election.csv "
            f"is in the same folder as this script."
        )
    df = pd.read_csv(path)
    df.columns = [c.strip().lower() for c in df.columns]
    return df


def find_relevant_rows(df: pd.DataFrame, query: str) -> pd.DataFrame:
    """Keyword-based retrieval: matches query against district, constituency,
    candidate name, party, and role columns."""
    q = query.lower()
    mask = pd.Series(False, index=df.index)

    for col in ("district", "constituency", "candidate_name", "party", "role"):
        if col in df.columns:
            mask |= df[col].astype(str).str.lower().apply(lambda v: v in q or q in v)

    words = re.findall(r"[a-zA-Z]+", q)
    for col in ("district", "constituency", "candidate_name"):
        if col in df.columns:
            for w in words:
                if len(w) > 3:
                    mask |= df[col].astype(str).str.lower().str.contains(w, na=False)

    matched = df[mask]
    return matched if not matched.empty else df  # fall back to full data


def rows_to_context(rows: pd.DataFrame, max_rows: int = 20) -> str:
    rows = rows.head(max_rows)
    lines = []
    for _, r in rows.iterrows():
        lines.append(
            f"- District: {r.get('district', 'N/A')} | "
            f"Constituency: {r.get('constituency', 'N/A')} | "
            f"Candidate: {r.get('candidate_name', 'N/A')} | "
            f"Party: {r.get('party', 'N/A')} | "
            f"Role: {r.get('role', 'N/A')} | "
            f"Votes: {r.get('votes', 'N/A')} | "
            f"Vote %: {r.get('vote_percent', 'N/A')} | "
            f"Margin: {r.get('margin', 'N/A')} | "
            f"Source: {r.get('source', 'N/A')}"
        )
    return "\n".join(lines)


def chat():
    print("=" * 60)
    print(" Gadag & Koppal 2023 Election Candidate Info Chatbot")
    print(" Ask about any constituency's winner or runner-up.")
    print(" Type 'exit' or 'quit' to end.")
    print("=" * 60)

    try:
        df = load_data(CSV_PATH)
    except FileNotFoundError as e:
        print(f"\n[Setup needed] {e}")
        return

    messages = [{"role": "system", "content": SYSTEM_PROMPT}]

    while True:
        query = input("\nYou: ").strip()
        if query.lower() in ("exit", "quit"):
            print("ElectionInfoBot: Goodbye!")
            break
        if not query:
            continue

        relevant = find_relevant_rows(df, query)
        context = rows_to_context(relevant)

        user_message = f"CANDIDATE DATA:\n{context}\n\nQUESTION: {query}"
        messages.append({"role": "user", "content": user_message})

        try:
            response = ollama.chat(model=MODEL_NAME, messages=messages)
            reply = response["message"]["content"]
        except Exception as e:
            print(f"\n[Error] Could not reach Ollama: {e}")
            print("Make sure Ollama is running (`ollama serve`) and llama3.2:latest is pulled.")
            break

        print(f"\nElectionInfoBot: {reply}")
        messages.append({"role": "assistant", "content": reply})


if __name__ == "__main__":
    chat()
